from __future__ import annotations

import json
import sqlite3
from typing import List, Dict


def read_events_from_db(db_path: str) -> List[Dict]:
    """
    Read all events from a SQLite database file
    
    Returns:
        List of event dictionaries with parsed JSON payloads
    """
    events = []
    
    with sqlite3.connect(db_path) as conn:
        cursor = conn.execute(
            """
            SELECT id, topic, replay_id, event_id, payload
            FROM events
            ORDER BY id
            """
        )
        
        for row in cursor:
            event = {
                "id": row[0],
                "topic": row[1],
                "replay_id": row[2],
                "event_id": row[3],
                "payload": json.loads(row[4]) if row[4] else {}
            }
            events.append(event)
    
    return events

