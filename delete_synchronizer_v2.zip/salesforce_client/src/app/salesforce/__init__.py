"""Salesforce integration package (auth, pubsub)."""

