"""App module containing domain-specific logic."""

