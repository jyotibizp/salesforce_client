"""Schemas for SQLite storage."""

