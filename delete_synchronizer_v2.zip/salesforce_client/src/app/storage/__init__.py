"""Storage layer (Azure Blob uploads)."""

